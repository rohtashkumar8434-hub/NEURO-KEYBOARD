# NEURO KEYBOARD — 8-System Modular Architecture

1. **Keyboard Engine (`feature/keyboard`)**: Independent `InputMethodService`, `InputConnection`, QWERTY/Hindi/Hinglish layouts, `SuggestionEngine`, and `ClipboardManager`. Works 100% offline.
2. **Offline AI Engine (`feature/offline`)**: Google LiteRT-LM on-device inference (`LocalAIEngine`) for grammar, translation, and short-context replies.
3. **Online AI Engine (`feature/online`)**: Pluggable `AIProvider` interface supporting custom cloud models without hardcoding API keys.
4. **Context & Memory Engine (`feature/memory`)**: Tracks topic continuity (e.g., Food -> Pizza preference) with user-controlled memory wipe.
5. **Screen & Automation Engine (`feature/automation`)**: Google Play compliant `AccessibilityService` — drafts replies only on user command and never presses Send automatically.
6. **Voice Engine (`feature/voice`)**: Speech-to-Text for Hindi, Hinglish, and English.
7. **Privacy & Security Engine (`core/security`)**: AES-256 `EncryptedSharedPreferences` for API keys and automatic AI shutoff on password inputs.
8. **Presentation Layer (`MainActivity`, `NeuroTheme`)**: Dark Blue / Purple Jetpack Compose UI.
