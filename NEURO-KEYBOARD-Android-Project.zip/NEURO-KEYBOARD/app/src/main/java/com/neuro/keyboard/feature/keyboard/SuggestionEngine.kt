package com.neuro.keyboard.feature.keyboard

/**
 * Offline Word & Hinglish Transliteration Suggestion Engine.
 * Works 100% independently of AI or internet connection.
 */
class SuggestionEngine {
    private val hinglishMap = mapOf(
        "kya" to listOf("क्या", "kya", "क्यों"),
        "kaise" to listOf("कैसे", "kaise", "कैसा"),
        "hai" to listOf("है", "hai", "हैं"),
        "mein" to listOf("मैं", "में", "mein"),
        "tum" to listOf("तुम", "तुम्हें", "tum"),
        "bhai" to listOf("भाई", "bhai", "भाईजान"),
        "accha" to listOf("अच्छा", "accha", "अच्छी"),
        "namaste" to listOf("नमस्ते", "namaste", "नमस्कार"),
        "khana" to listOf("खाना", "khana", "खाने"),
        "pizza" to listOf("पिज्जा", "pizza", "🍕")
    )

    private val defaultNextWords = listOf("भाई", "क्या हाल है?", "ठीक है", "धन्यवाद", "Okay")

    fun suggest(currentWord: String, language: LanguageMode): List<String> {
        if (currentWord.isBlank()) return defaultNextWords
        val lower = currentWord.lowercase()
        if (language == LanguageMode.HINGLISH || language == LanguageMode.HINDI) {
            hinglishMap[lower]?.let { return it }
        }
        return listOf(
            currentWord,
            currentWord.replaceFirstChar { it.uppercase() },
            "${currentWord}s"
        )
    }
}
