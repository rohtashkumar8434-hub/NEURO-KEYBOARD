package com.neuro.keyboard.feature.automation

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * E. Screen & Automation Engine (Google Play Policy Compliant)
 * - NEVER auto-clicks Send or acts autonomously.
 * - Reads screen context ONLY when user explicitly triggers AI Assist,
 *   drafts the reply in the input field, and waits for user confirmation.
 */
class NeuroAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Passive listener: only caches active package name when user approves
    }

    override fun onInterrupt() {
        // Clean stop on service interrupt
    }
}
