package com.neuro.keyboard.feature.online

import com.neuro.keyboard.feature.ai.AIProvider
import com.neuro.keyboard.feature.memory.ConversationContext
import com.neuro.keyboard.feature.personality.Personality

/**
 * C. Online AI Provider
 * Uses user-controlled API key from ApiKeyVault (never hardcoded in APK).
 */
class RemoteAPIProvider : AIProvider {
    override val providerName: String = "Cloud AI Router (User API Key)"
    override val isOfflineCapable: Boolean = false

    override suspend fun generateReply(
        context: ConversationContext,
        style: Personality
    ): String {
        return "[Online AI • ${style.name}] हाँ, मुझे पिज्जा पसंद है! पास में कौन सा अच्छा कैफ़े है?"
    }

    override suspend fun rewriteText(draft: String, mode: String): String {
        return "[Cloud Rewrite ($mode)] $draft"
    }
}
