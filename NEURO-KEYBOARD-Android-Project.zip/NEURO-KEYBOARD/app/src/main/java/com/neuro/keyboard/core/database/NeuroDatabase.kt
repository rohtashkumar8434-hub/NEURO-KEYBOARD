package com.neuro.keyboard.core.database

import android.content.Context
import androidx.room.*

@Entity(tableName = "clipboard_items")
data class ClipboardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val pinned: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_memory")
data class MemoryNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val topic: String,
    val preferenceValue: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface NeuroDao {
    @Query("SELECT * FROM clipboard_items ORDER BY pinned DESC, timestamp DESC LIMIT 30")
    suspend fun getClipboardHistory(): List<ClipboardEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClipboard(item: ClipboardEntity)

    @Query("DELETE FROM clipboard_items WHERE pinned = 0")
    suspend fun clearUnpinnedClipboard()

    @Query("SELECT * FROM user_memory ORDER BY updatedAt DESC")
    suspend fun getMemories(): List<MemoryNoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveMemory(note: MemoryNoteEntity)

    @Query("DELETE FROM user_memory")
    suspend fun wipeAllMemory()
}

@Database(entities = [ClipboardEntity::class, MemoryNoteEntity::class], version = 1, exportSchema = false)
abstract class NeuroDatabase : RoomDatabase() {
    abstract fun neuroDao(): NeuroDao

    companion object {
        @Volatile
        private var INSTANCE: NeuroDatabase? = null

        fun getInstance(context: Context): NeuroDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    NeuroDatabase::class.java,
                    "neuro_keyboard.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}
