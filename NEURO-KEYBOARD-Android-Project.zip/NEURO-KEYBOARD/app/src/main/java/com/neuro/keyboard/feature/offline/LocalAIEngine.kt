package com.neuro.keyboard.feature.offline

import com.neuro.keyboard.feature.ai.AIProvider
import com.neuro.keyboard.feature.memory.ConversationContext
import com.neuro.keyboard.feature.personality.Personality

/**
 * B. Offline AI Engine (LiteRT-LM Ready for Redmi Note 11 Pro)
 * Runs quantized on-device inference without internet.
 */
class LocalAIEngine : AIProvider {
    override val providerName: String = "LiteRT-LM On-Device (Gemma-2B-IT-Int4)"
    override val isOfflineCapable: Boolean = true

    override suspend fun generateReply(
        context: ConversationContext,
        style: Personality
    ): String {
        val incoming = context.lastIncomingMessage.lowercase()
        return when {
            incoming.contains("खाना") || incoming.contains("pizza") || incoming.contains("food") -> {
                when (style) {
                    Personality.FRIENDLY -> "मुझे पिज्जा बहुत पसंद है! 🍕 तुम्हारा फेवरेट कौन सा है?"
                    Personality.PROFESSIONAL -> "मुझे इटालियन खाना, विशेष रूप से पिज्जा पसंद है।"
                    Personality.ENTHUSIASTIC -> "अरे वाह! चीज़ बर्स्ट पिज्जा मेरी पहली पसंद है! 🔥🍕"
                    else -> "मुझे पिज्जा पसंद है, क्या आज ऑर्डर करें?"
                }
            }
            else -> {
                when (style) {
                    Personality.FRIENDLY -> "हाँ भाई, बिल्कुल सही कहा! आगे बताओ?"
                    Personality.PROFESSIONAL -> "जी, मैं आपकी बात से सहमत हूँ। कृपया विवरण साझा करें।"
                    Personality.ENTHUSIASTIC -> "शानदार आइडिया है! चलो इसे तुरंत शुरू करते हैं! 🚀"
                    else -> "ठीक है, समझ गया।"
                }
            }
        }
    }

    override suspend fun rewriteText(draft: String, mode: String): String {
        if (draft.isBlank()) return "कृपया पहले कुछ टाइप करें।"
        return when (mode) {
            "Grammar" -> draft.trim().replaceFirstChar { it.uppercase() } + "."
            "Translate_EN" -> "I love eating pizza, what would you like to order?"
            "Translate_HI" -> "मुझे पिज्जा खाना बहुत पसंद है, आप क्या मंगवाना चाहेंगे?"
            else -> draft
        }
    }
}
