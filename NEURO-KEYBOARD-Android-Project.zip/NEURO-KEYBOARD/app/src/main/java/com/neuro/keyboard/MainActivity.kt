package com.neuro.keyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.neuro.keyboard.core.designsystem.NeuroTheme
import com.neuro.keyboard.feature.settings.SettingsScreen
import com.neuro.keyboard.feature.settings.PrivacySettings

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NeuroTheme {
                var selectedTab by remember { mutableIntStateOf(0) }
                Scaffold(
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF10132B)) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                label = { Text("Setup & Test") },
                                icon = {}
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                label = { Text("AI Dashboard") },
                                icon = {}
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                label = { Text("Privacy & Vault") },
                                icon = {}
                            )
                        }
                    }
                ) { padding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFF0B0C1E), Color(0xFF1A103C))
                                )
                            )
                    ) {
                        when (selectedTab) {
                            0 -> SettingsScreen(
                                onEnableKeyboard = {
                                    startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                                },
                                onSelectKeyboard = {
                                    val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                                    imm.showInputMethodPicker()
                                },
                                onOpenAccessibility = {
                                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                }
                            )
                            1 -> com.neuro.keyboard.feature.personality.AIDashboardScreen()
                            2 -> PrivacySettings()
                        }
                    }
                }
            }
        }
    }
}
