package com.neuro.keyboard.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PrivacySettings() {
    var apiKey by remember { mutableStateOf("") }
    var incognitoMode by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Privacy & Security Center", fontSize = 22.sp, color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Incognito Mode (Pause Memory & History)", color = Color.White)
            Switch(checked = incognitoMode, onCheckedChange = { incognitoMode = it })
        }

        OutlinedTextField(
            value = apiKey,
            onValueChange = { apiKey = it },
            label = { Text("Custom Online AI API Key (Encrypted in Keystore)") },
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            "✓ Password fields automatically disable AI & Clipboard.
✓ No API keys are hardcoded in the APK.
✓ Private chats are never recorded in background.",
            color = Color(0xFF34D399),
            fontSize = 13.sp
        )
    }
}
