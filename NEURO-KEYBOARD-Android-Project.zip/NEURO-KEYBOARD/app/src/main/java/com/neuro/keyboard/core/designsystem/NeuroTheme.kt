package com.neuro.keyboard.core.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NeuroDarkBlue = Color(0xFF0B0C1E)
val NeuroDeepPurple = Color(0xFF251651)
val NeuroElectricPurple = Color(0xFF8B5CF6)
val NeuroNeonPink = Color(0xFFD946EF)
val NeuroCyanAccent = Color(0xFF06B6D4)

private val NeuroColorScheme = darkColorScheme(
    primary = NeuroElectricPurple,
    secondary = NeuroNeonPink,
    tertiary = NeuroCyanAccent,
    background = NeuroDarkBlue,
    surface = Color(0xFF151836),
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun NeuroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NeuroColorScheme,
        content = content
    )
}
