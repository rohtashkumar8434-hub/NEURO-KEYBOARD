package com.neuro.keyboard.feature.keyboard

enum class KeyboardMode {
    QWERTY, NUMBERS, SYMBOLS
}

enum class LanguageMode(val label: String) {
    ENGLISH("EN"),
    HINGLISH("पा/EN"),
    HINDI("हिन्दी")
}

object LayoutManager {
    val numberRow = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

    val qwertyRows = listOf(
        listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"),
        listOf("A", "S", "D", "F", "G", "H", "J", "K", "L"),
        listOf("Z", "X", "C", "V", "B", "N", "M")
    )

    val hindiRows = listOf(
        listOf("ौ", "ै", "ा", "ी", "ू", "ब", "ह", "ग", "द", "ज", "ड"),
        listOf("ो", "े", "्", "ि", "ु", "प", "र", "क", "त", "च", "ट"),
        listOf("ं", "म", "न", "व", "ल", "स", "य", "श", "ष")
    )

    val symbolRows = listOf(
        listOf("@", "#", "₹", "%", "&", "-", "+", "(", ")", "/"),
        listOf("*", "\"", "'", ":", ";", "!", "?", "~", "`"),
        listOf("=", "{", "}", "[", "]", "<", ">", "_", "|")
    )
}
