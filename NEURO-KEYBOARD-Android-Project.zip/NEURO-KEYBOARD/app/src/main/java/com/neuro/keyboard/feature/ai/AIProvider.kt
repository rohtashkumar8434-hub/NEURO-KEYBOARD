package com.neuro.keyboard.feature.ai

import com.neuro.keyboard.feature.memory.ConversationContext
import com.neuro.keyboard.feature.personality.Personality

/**
 * C. Core AI Provider Interface
 * Decouples the keyboard from any single AI vendor or model.
 */
interface AIProvider {
    val providerName: String
    val isOfflineCapable: Boolean

    suspend fun generateReply(
        context: ConversationContext,
        style: Personality
    ): String

    suspend fun rewriteText(
        draft: String,
        mode: String // Grammar, Translate, Shorter, Formal
    ): String
}
