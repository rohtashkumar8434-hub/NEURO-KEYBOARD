package com.neuro.keyboard.feature.keyboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neuro.keyboard.feature.ai.AIModelRouter
import com.neuro.keyboard.feature.memory.ConversationContext
import com.neuro.keyboard.feature.personality.Personality
import kotlinx.coroutines.launch

@Composable
fun KeyboardView(
    keyHandler: KeyHandler,
    suggestionEngine: SuggestionEngine,
    isPasswordMode: Boolean
) {
    val scope = rememberCoroutineScope()
    var isShifted by remember { mutableStateOf(true) }
    var mode by remember { mutableStateOf(KeyboardMode.QWERTY) }
    var language by remember { mutableStateOf(LanguageMode.HINGLISH) }
    var showAIPanel by remember { mutableStateOf(false) }
    var currentWord by remember { mutableStateOf("") }
    var selectedPersonality by remember { mutableStateOf(Personality.FRIENDLY) }
    var aiReplies by remember { mutableStateOf<List<String>>(emptyList()) }

    val suggestions = remember(currentWord, language) {
        suggestionEngine.suggest(currentWord, language)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFF141238), Color(0xFF4C1D95), Color(0xFFA21CAF))
                )
            )
            .padding(vertical = 6.dp, horizontal = 4.dp)
    ) {
        // Top AI Toolbar & Suggestion Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!isPasswordMode) {
                Button(
                    onClick = {
                        showAIPanel = !showAIPanel
                        if (showAIPanel) {
                            scope.launch {
                                aiReplies = AIModelRouter.generateSmartReplies(
                                    ConversationContext(
                                        lastIncomingMessage = "तुम्हें कौन सा खाना पसंद है?",
                                        currentDraft = currentWord
                                    ),
                                    selectedPersonality
                                )
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(if (showAIPanel) "⌨️ Keys" else "✨ AI Reply", fontSize = 12.sp)
                }
            } else {
                Text(
                    "🔒 Password Field (AI Off)",
                    color = Color(0xFFFBBF24),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }

            // Suggestions
            Row(
                modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                suggestions.take(3).forEach { word ->
                    Text(
                        text = word,
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.14f))
                            .clickable {
                                keyHandler.commitText("$word ")
                                currentWord = ""
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            // Language Switcher
            Text(
                text = language.label,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.2f))
                    .clickable {
                        language = when (language) {
                            LanguageMode.ENGLISH -> LanguageMode.HINGLISH
                            LanguageMode.HINGLISH -> LanguageMode.HINDI
                            LanguageMode.HINDI -> LanguageMode.ENGLISH
                        }
                    }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            )
        }

        if (showAIPanel && !isPasswordMode) {
            // 2. AI Reply Panel inside Keyboard
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1026))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("NEURO AI Assistant (Offline LiteRT + Online)", color = Color(0xFFC084FC), fontSize = 12.sp)
                    Text(
                        text = "Tone: ${selectedPersonality.name}",
                        color = Color.White,
                        fontSize = 12.sp,
                        modifier = Modifier.clickable {
                            val entries = Personality.entries
                            selectedPersonality = entries[(selectedPersonality.ordinal + 1) % entries.size]
                        }
                    )
                }

                aiReplies.forEach { reply ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E1B4B))
                            .clickable {
                                keyHandler.replaceDraftWithAI(reply)
                                showAIPanel = false
                            }
                            .padding(10.dp)
                    ) {
                        Text(reply, color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        } else {
            // 1. Standard QWERTY / Hindi / Symbols Keyboard Rows
            val rows = when {
                mode == KeyboardMode.SYMBOLS -> LayoutManager.symbolRows
                language == LanguageMode.HINDI -> LayoutManager.hindiRows
                else -> LayoutManager.qwertyRows
            }

            rows.forEachIndexed { rowIndex, rowKeys ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally)
                ) {
                    if (rowIndex == 2) {
                        KeyButton(
                            label = "⇧",
                            modifier = Modifier.weight(1.3f),
                            onClick = { isShifted = !isShifted }
                        )
                    }
                    rowKeys.forEach { key ->
                        val displayKey = if (isShifted) key.uppercase() else key.lowercase()
                        val numberHint = if (rowIndex == 0 && mode == KeyboardMode.QWERTY && rowKeys.indexOf(key) < 10) {
                            LayoutManager.numberRow[rowKeys.indexOf(key)]
                        } else null

                        KeyButton(
                            label = displayKey,
                            subLabel = numberHint,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                keyHandler.commitText(displayKey)
                                currentWord += displayKey
                                if (isShifted && currentWord.length == 1) isShifted = false
                            }
                        )
                    }
                    if (rowIndex == 2) {
                        KeyButton(
                            label = "⌫",
                            modifier = Modifier.weight(1.3f),
                            onClick = {
                                keyHandler.handleBackspace()
                                if (currentWord.isNotEmpty()) {
                                    currentWord = currentWord.dropLast(1)
                                }
                            }
                        )
                    }
                }
            }

            // Bottom Row (?123, Emoji, Spacebar, Voice, Enter)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                KeyButton(
                    label = if (mode == KeyboardMode.QWERTY) "?123" else "ABC",
                    modifier = Modifier.weight(1.3f),
                    onClick = {
                        mode = if (mode == KeyboardMode.QWERTY) KeyboardMode.SYMBOLS else KeyboardMode.QWERTY
                    }
                )
                KeyButton(
                    label = "😊",
                    modifier = Modifier.weight(1f),
                    bgColor = Color(0xFFFACC15),
                    textColor = Color.Black,
                    onClick = { keyHandler.commitText("😊") }
                )
                KeyButton(
                    label = "NEURO Space (${language.label})",
                    modifier = Modifier.weight(4f),
                    onClick = {
                        keyHandler.handleSpace()
                        currentWord = ""
                    }
                )
                KeyButton(
                    label = "🎤",
                    modifier = Modifier.weight(1f),
                    onClick = { /* Voice input trigger */ }
                )
                KeyButton(
                    label = "↵",
                    modifier = Modifier.weight(1.4f),
                    bgColor = Color(0xFF06B6D4),
                    onClick = {
                        keyHandler.handleEnter()
                        currentWord = ""
                    }
                )
            }
        }
    }
}

@Composable
private fun KeyButton(
    label: String,
    subLabel: String? = null,
    modifier: Modifier = Modifier,
    bgColor: Color = Color.White.copy(alpha = 0.16f),
    textColor: Color = Color.White,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (subLabel != null) {
            Text(
                text = subLabel,
                color = textColor.copy(alpha = 0.65f),
                fontSize = 9.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 2.dp, end = 4.dp)
            )
        }
        Text(
            text = label,
            color = textColor,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
