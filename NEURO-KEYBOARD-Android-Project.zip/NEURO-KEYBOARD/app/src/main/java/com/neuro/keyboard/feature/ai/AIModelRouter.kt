package com.neuro.keyboard.feature.ai

import com.neuro.keyboard.feature.memory.ConversationContext
import com.neuro.keyboard.feature.offline.LocalAIEngine
import com.neuro.keyboard.feature.online.RemoteAPIProvider
import com.neuro.keyboard.feature.personality.Personality

object AIModelRouter {
    private val localProvider: AIProvider = LocalAIEngine()
    private val remoteProvider: AIProvider = RemoteAPIProvider()

    var preferOfflineMode: Boolean = true

    suspend fun generateSmartReplies(
        context: ConversationContext,
        style: Personality
    ): List<String> {
        val primary = if (preferOfflineMode) localProvider else remoteProvider
        return listOf(
            primary.generateReply(context, style),
            localProvider.generateReply(context, Personality.PROFESSIONAL),
            localProvider.generateReply(context, Personality.ENTHUSIASTIC)
        )
    }
}
