package com.neuro.keyboard

import android.app.Application
import com.neuro.keyboard.core.database.NeuroDatabase
import com.neuro.keyboard.core.security.ApiKeyVault

class NeuroApplication : Application() {
    lateinit var database: NeuroDatabase
        private set
    lateinit var apiKeyVault: ApiKeyVault
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = NeuroDatabase.getInstance(this)
        apiKeyVault = ApiKeyVault(this)
    }

    companion object {
        lateinit var instance: NeuroApplication
            private set
    }
}
