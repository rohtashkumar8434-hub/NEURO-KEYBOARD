package com.neuro.keyboard.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(
    onEnableKeyboard: () -> Unit,
    onSelectKeyboard: () -> Unit,
    onOpenAccessibility: () -> Unit
) {
    var testInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("NEURO KEYBOARD v1.0", fontSize = 24.sp, color = Color.White)
        Text(
            "Free & Open Source • Offline + Online AI • Redmi Note 11 Pro Ready",
            fontSize = 13.sp,
            color = Color(0xFFA78BFA)
        )

        Button(
            onClick = onEnableKeyboard,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
        ) {
            Text("Step 1: Enable NEURO Keyboard in Android Settings")
        }

        Button(
            onClick = onSelectKeyboard,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
        ) {
            Text("Step 2: Switch Active Keyboard to NEURO")
        }

        OutlinedButton(
            onClick = onOpenAccessibility,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Optional: Enable User-Confirmed Context Reader", color = Color.White)
        }

        OutlinedTextField(
            value = testInput,
            onValueChange = { testInput = it },
            label = { Text("Tap here to test NEURO Keyboard live") },
            modifier = Modifier.fillMaxWidth()
        )
    }
}
