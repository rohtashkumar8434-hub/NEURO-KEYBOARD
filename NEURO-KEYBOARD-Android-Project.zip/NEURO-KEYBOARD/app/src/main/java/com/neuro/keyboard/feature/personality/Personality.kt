package com.neuro.keyboard.feature.personality

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neuro.keyboard.feature.ai.AIModelRouter

enum class Personality {
    DEFAULT, FRIENDLY, PROFESSIONAL, ENTHUSIASTIC, WITTY
}

@Composable
fun AIDashboardScreen() {
    var offlinePreferred by remember { mutableStateOf(AIModelRouter.preferOfflineMode) }
    var selectedTone by remember { mutableStateOf(Personality.FRIENDLY) }
    var responseLength by remember { mutableStateOf("Auto") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("AI Dashboard & Model Router", fontSize = 22.sp, color = Color.White)

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171838)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("AI Engine Mode", color = Color(0xFFC084FC), fontSize = 14.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        if (offlinePreferred) "Offline (LiteRT-LM On-Device)" else "Online (Custom API Key)",
                        color = Color.White
                    )
                    Switch(
                        checked = offlinePreferred,
                        onCheckedChange = {
                            offlinePreferred = it
                            AIModelRouter.preferOfflineMode = it
                        }
                    )
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171838)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Reply Tone / Personality", color = Color(0xFFC084FC), fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Personality.entries.take(3).forEach { tone ->
                        FilterChip(
                            selected = selectedTone == tone,
                            onClick = { selectedTone = tone },
                            label = { Text(tone.name) }
                        )
                    }
                }
                Text("Response Length: $responseLength (Auto / Short / Long)", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}
