package com.neuro.keyboard.core.security

import android.content.Context
import android.view.inputmethod.EditorInfo
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * G. Privacy & Security Engine
 * - Never hardcodes API keys in APK
 * - Encrypts keys locally using Android Keystore
 * - Automatically detects password/sensitive fields so AI & clipboard stay OFF
 */
class ApiKeyVault(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "neuro_secure_vault",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveApiKey(provider: String, apiKey: String) {
        prefs.edit().putString("api_key_$provider", apiKey.trim()).apply()
    }

    fun getApiKey(provider: String): String? {
        return prefs.getString("api_key_$provider", null)
    }

    fun clearAllSecrets() {
        prefs.edit().clear().apply()
    }

    companion object {
        fun isSensitivePasswordField(editorInfo: EditorInfo?): Boolean {
            if (editorInfo == null) return false
            val variation = editorInfo.inputType and EditorInfo.TYPE_MASK_VARIATION
            return variation == EditorInfo.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == EditorInfo.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == EditorInfo.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == EditorInfo.TYPE_NUMBER_VARIATION_PASSWORD
        }
    }
}
