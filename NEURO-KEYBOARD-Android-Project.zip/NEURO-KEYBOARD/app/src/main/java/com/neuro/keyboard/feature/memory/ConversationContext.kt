package com.neuro.keyboard.feature.memory

/**
 * D. Context & Memory Engine Model
 * Holds temporary user-approved conversation context.
 * No permanent background recording of private chats by default.
 */
data class ConversationContext(
    val lastIncomingMessage: String = "",
    val previousReply: String = "",
    val currentDraft: String = "",
    val preferredLanguage: String = "Hinglish",
    val responseLength: String = "Auto"
)
