package com.neuro.keyboard.feature.keyboard

import android.view.KeyEvent
import android.view.inputmethod.InputConnection

class KeyHandler(private val inputConnectionProvider: () -> InputConnection?) {

    fun commitText(text: String) {
        inputConnectionProvider()?.commitText(text, 1)
    }

    fun handleBackspace() {
        val ic = inputConnectionProvider() ?: return
        val selected = ic.getSelectedText(0)
        if (selected.isNullOrEmpty()) {
            ic.deleteSurroundingText(1, 0)
        } else {
            ic.commitText("", 1)
        }
    }

    fun handleSpace() {
        inputConnectionProvider()?.commitText(" ", 1)
    }

    fun handleEnter() {
        inputConnectionProvider()?.sendKeyEvent(
            KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)
        )
        inputConnectionProvider()?.sendKeyEvent(
            KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER)
        )
    }

    fun replaceDraftWithAI(newText: String) {
        val ic = inputConnectionProvider() ?: return
        ic.beginBatchEdit()
        val before = ic.getTextBeforeCursor(500, 0) ?: ""
        val after = ic.getTextAfterCursor(500, 0) ?: ""
        ic.deleteSurroundingText(before.length, after.length)
        ic.commitText(newText, 1)
        ic.endBatchEdit()
    }
}
