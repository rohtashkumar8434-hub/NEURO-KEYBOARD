# NEURO KEYBOARD
**Free & Open Source | Offline + Online AI | Android Communication System**

> **Vision:** A keyboard that understands, communicates, and assists — while keeping basic typing 100% independent of AI and internet connectivity.

## Core Principles
| Component | Decision |
|---|---|
| **Platform** | Android (Min SDK 26, Target SDK 34 — Tested for Redmi Note 11 Pro / Android 13) |
| **Language** | Kotlin |
| **UI** | Jetpack Compose |
| **Keyboard** | Android `InputMethodService` |
| **AI** | Offline (Google LiteRT-LM) + Online (`AIProvider` Router) |
| **Database** | Room + SQLite |
| **Design** | Dark Blue / Electric Purple Theme |
| **License** | Apache 2.0 |
| **Privacy** | User-controlled, Encrypted Key Vault, Auto-disabled on Password Fields |

## How to Build the APK

### Option 1: Android Studio (PC / Laptop)
1. Extract `NEURO-KEYBOARD-Android-Project.zip`.
2. Open **Android Studio** -> **Open** -> Select the `NEURO-KEYBOARD` folder.
3. Let Gradle sync finish, then click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install `app/build/outputs/apk/debug/app-debug.apk` on your **Redmi Note 11 Pro**.

### Option 2: Chrome Only (Mobile / Cloud via GitHub Actions)
1. Create a free repository on GitHub from Chrome and upload these project files.
2. Go to the **Actions** tab — the included `.github/workflows/android-apk-build.yml` workflow will automatically compile the project in the cloud and give you a downloadable `neuro-keyboard-debug.apk`!
